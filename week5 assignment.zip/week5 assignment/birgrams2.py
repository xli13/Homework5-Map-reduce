from mrjob.job import MRJob
from mrjob.step import MRStep
import re
import heapq
WORD_RE = re.compile(r"[\w']+")
class bigrams2(MRJob):
    def mapper(self, _, line):
        """
        """
        l = WORD_RE.findall(line.lower())
        for i in range(len(l)-1): #use set here
            yield set([l[i],l[i+1]]),1

    def reducer_sum(self, key, val):
        yield None,[sum(val),key]

    def reducer_top10(self,_,values): #we only need top 10
        for cnt,val in heapq.nlargest(10,values):
            yield cnt,val

    def steps(self):
        return [MRStep(mapper=self.mapper, reducer=self.reducer_sum),MRStep(reducer=self.reducer_top10)]


if __name__ == '__main__':
    bigrams2.run()
